import streamlit as st
import joblib
import numpy as np

# Load pipeline and encoder
pipeline = joblib.load("liver_pipeline.pkl")
encoder = joblib.load("Label_Encoder.pkl")

# Page config
st.set_page_config(page_title="Liver Disease Prediction", page_icon="🩺", layout="wide")

# CSS
st.markdown("""
<style>
/* Default page background white and navy text for labels */
.stApp .block-container {
    background-color: white;
    color: #001f3f; /* default text */
    padding-top: 20px;
}

/* Input labels navy */
label {
    color: #001f3f !important;
    font-weight: bold;
}

/* Input boxes readable */
.stNumberInput input, .stTextInput input {
    color: #001f3f !important;
    background-color: #ffffff !important;
}

/* Headings inherit color */
.stApp h1, .stApp h2, .stApp h3 {
    color: inherit;
}

/* Divider color */
hr {
    border-color: #001f3f;
}

/* Predict button font color white on navy */
.stButton>button {
    color: white !important;
    font-weight: bold;
    background-color: #001f3f;
    border: none;
}
</style>
""", unsafe_allow_html=True)

# Navy top header section
st.markdown("""
<div style='background-color:#001f3f; padding: 50px 20px;'>
<h1 style='color:white; margin:0;'>🩺 Liver Disease Prediction App</h1>
<h3 style='color:white; margin:0;'>Enter patient details below to predict the type of liver disease</h3>
</div>
""", unsafe_allow_html=True)

st.markdown("---")

# Input Section
st.header("Patient Demographics")
age = st.number_input("Age", min_value=0, max_value=120, step=1)

st.header("Biochemical Test Results")
col1, col2, col3 = st.columns(3)

with col1:
    alb = st.number_input("Albumin", step=0.1)
    alp = st.number_input("Alkaline Phosphatase", step=0.1)
    alt = st.number_input("Alanine Aminotransferase", step=0.1)

with col2:
    ast = st.number_input("Aspartate Aminotransferase", step=0.1)
    bil = st.number_input("Bilirubin", step=0.1)
    che = st.number_input("Cholinesterase", step=0.1)

with col3:
    chol = st.number_input("Cholesterol", step=0.1)
    crea = st.number_input("Creatinine", step=0.1)
    ggt = st.number_input("Gamma-Glutamyl Transferase", step=0.1)
    prot = st.number_input("Total Protein", step=0.1)

# Prepare features
features = np.array([[age, alb, alp, alt, ast, bil, che, chol, crea, ggt, prot]])

# Prediction
if st.button("Predict"):
    try:
        prediction = pipeline.predict(features)
        result = encoder.inverse_transform(prediction)[0]

        # Prediction text
        if result.lower() == "blood donor":
            st.markdown(f"<h1 style='color:green'>Patient is a : {result}</h1>", unsafe_allow_html=True)
        else:
            st.markdown(f"<h1 style='color:red'>Patient has : {result}</h1>", unsafe_allow_html=True)
    except Exception as e:
        st.error(f"Error predicting: {e}")
